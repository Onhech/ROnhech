#'Setup a working directory and read files in Google Drive
#'
#'Using Google Drive to host and sync R files is a great way to ensure you can access and modify you works regardless of where you are or what computer you use. However, when attempting to run code across various machines you run into problems with working directory and file paths. This typically would require changing your working directory every time you switch workstations. The gdsetup package offers a single line command to dynamically change your working directory regardless of what computer you are using. As long as you are synchronizing your Google Drive on the computer, it will update the working director and file location. Further, it will load your file
#'
#'@param qfile Standard Qualtrics CSV export
#'
#'@return Formatted Qualtrics dataframe
#'
#'@examples
#'qformat("C:/Users/Onhech/Google Drive/Research/Biology/Iris.csv")
#'
#'@export

qformat<-function(qfile)
  {
  firstcolumnnames<-colnames(qfile)
  secondcolumnnames<-as.character(unlist(qfile[1,]))
  colnames(secondcolumnnames)<-colnames(secondcolumnnames)
  left<-match("UserLanguage",firstcolumnnames)
  end<-match("SC0",firstcolumnnames)

  colnames(qfile)[end:length(qfile)]<-secondcolumnnames[end:length(qfile)]

  qfile<-qfile[-c(1,2),]
  qfile<-qfile[,-c(1:left)]
  return(qfile)
  }
