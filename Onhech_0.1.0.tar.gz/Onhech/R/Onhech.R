#' Google Drive Package
#'
#' Contains various useful functions made for personal use.
#'
#' @docType package
#'
#' @author Lynden Jensen \email{Lynden.Jensen@Gmail.com}
#'
#' @name Onhech
NULL
