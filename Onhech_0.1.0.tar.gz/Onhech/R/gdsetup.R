#'Setup a working directory and read files in Google Drive
#'
#'Using Google Drive to host and sync R files is a great way to ensure you can access and modify you works regardless of where you are or what computer you use. However, when attempting to run code across various machines you run into problems with working directory and file paths. This typically would require changing your working directory every time you switch workstations. The gdsetup package offers a single line command to dynamically change your working directory regardless of what computer you are using. As long as you are synchronizing your Google Drive on the computer, it will update the working director and file location. Further, it will load your file
#'
#'@param Folder Example GD working directory path
#'@param csvFileName The filename of the csv you want to read in
#'
#'@return Confirmation of task completion or read csv file
#'
#'@examples
#'file<-gdsetup("C:/Users/Onhech/Google Drive/Research/Biology","Iris")
#'gdsetup("C:/Users/Lynden/Google Drive/Research/Psychology/Biology")
#'
#'@export

gdsetup<-function(Folder,csvFileName=""){
  setwd(paste("C:/Users/",Sys.getenv("USERNAME"),"/Google Drive",unlist(strsplit(Folder, split='Google Drive', fixed=TRUE))[2],sep = ""))
  ifelse(csvFileName=="",
      file<-"WD Updated--No File Specifed",
      file<-read.csv(paste("C:/Users/",Sys.getenv("USERNAME"),"/Google Drive",unlist(strsplit(Folder, split='Google Drive', fixed=TRUE))[2],"/",csvFileName,".csv",sep = "")))
  return(file)
    }
